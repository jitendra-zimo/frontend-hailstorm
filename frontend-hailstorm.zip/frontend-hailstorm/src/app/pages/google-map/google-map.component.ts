import { Component, OnInit,ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-google-map',
  templateUrl: './google-map.component.html',
  styleUrls: ['./google-map.component.scss']
})
export class GoogleMapComponent implements OnInit {
  @ViewChild('mapRef', {static: true }) mapElement: ElementRef;
  constructor() { }
  markers = []
  ngOnInit() {
    this.renderMap();
  }

  renderMap() {

    window['initMap'] = () => {
      this.loadMap();     
    }
    if(!window.document.getElementById('google-map-script')) {
      var s = window.document.createElement("script");
      s.id = "google-map-script";
      s.type = "text/javascript";
      s.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyC0y2S4-iE2rHkYdyAsglz_qirv0UtpF1s&callback=initMap&libraries=geometry,places,drawing&v=weekly&sensor=false";
  
      window.document.body.appendChild(s);
    } else {
      this.loadMap();
    }
  }

  loadMap = () => {
    var map = new window['google'].maps.Map(this.mapElement.nativeElement, {
      center: {lat: 39.3933648, lng: -95.6330846},
      zoom: 5
    });
  
  
    let tileNEX = '';
    //Load Images and add them to imageArray
    tileNEX = new window['google'].maps.ImageMapType({
        getTileUrl: function(tile, zoom) {
            return "http://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/nexrad-n0q-900913/" + zoom + "/" + tile.x + "/" + tile.y +".png?"+ (new Date()).getTime(); 
        },
        tileSize: new window['google'].maps.Size(256, 256),
        opacity:0.00,
        name : 'NEXRAD',
        isPng: true,
    });
    map.overlayMapTypes.push(tileNEX);

    var index = map.overlayMapTypes.getLength() - 1;

    window.setInterval(function(){

        map.overlayMapTypes.getAt(index).setOpacity(0.00);

        index--;
        if(index < 0){
            index = map.overlayMapTypes.getLength() - 1;
        }
        map.overlayMapTypes.getAt(index).setOpacity(0.60);
    }, 400);
    const image ="./assets/images/map-icon/4ef21eb9-2x.png";
    
    this.markers = [
      {
        position: new window['google'].maps.LatLng(39.0129703, -95.8484604),
        icon: image,
        map: map,
        title: "Topeka, KS, USA"
      },
      {
        position: new window['google'].maps.LatLng(38.6309768, -90.5950089),
        icon: image,
        map: map,
        title: "California, MO, USA"
      },
      {
        position: new window['google'].maps.LatLng(38.4157446, -121.5265747),
        icon: "./assets/images/map-icon/rmc_orange.png",
        label: {text:'28',color: "#fff",fontSize: "12px"},
        map: map,
        title: "Nevada, USA"
      },
      {
        position: new window['google'].maps.LatLng(36.1246721, -115.4558815),
        icon: image,
        map: map,
        title: "Las Vegas"
      },
      {
        position: new window['google'].maps.LatLng(37.5291269, -116.238471),
        icon: "./assets/images/map-icon/rmc_red.png",
        label: {text:'300',color: "#fff",fontSize: "12px"},
        map: map,
        title: "Crystal Springs"
      },
      {
        position: new window['google'].maps.LatLng(37.5430102, -110.4124491),
        icon: "./assets/images/map-icon/rmc_blue.png",
        label: {text:'3',color: "#fff",fontSize: "12px"},
        map: map,
        title: "California, MO, USA"
      }
    ];

    this.markers.forEach(markerInfo => {
      //Creating a new marker object
      const marker = new window['google'].maps.Marker({
        ...markerInfo
      });

      //creating a new info window with markers info
      const infoWindow = new window['google'].maps.InfoWindow({
        content: marker.getTitle()
      });

      //Add click event to open info window on marker
      marker.addListener("click", () => {
        infoWindow.open(marker.getMap(), marker);
      });

      //Adding marker to google map
      marker.setMap(map);
    });

    
    }


}
