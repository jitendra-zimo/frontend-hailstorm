import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagesRoutingModule } from './pages-routing.module';
import { GoogleMapComponent } from './google-map/google-map.component';
import { PagesComponent } from './pages.component';


@NgModule({
  declarations: [GoogleMapComponent,PagesComponent],
  imports: [
    CommonModule,
    PagesRoutingModule
  ]
})
export class PagesModule { }
